import { useEffect, useState } from "react";
import { FiTool, FiPower, FiSave } from "react-icons/fi";
import toast from "react-hot-toast";

import AdminLayout from "../../components/Admin/AdminLayout";
import api from "../../services/api";

const DEFAULT_MESSAGE =
  "Orbit Buy is undergoing scheduled maintenance. Please check back soon.";

// <input type="datetime-local"> needs "YYYY-MM-DDTHH:mm" in LOCAL time —
// toISOString() gives UTC, so this shifts by the timezone offset first.
const toLocalInputValue = (iso) => {
  if (!iso) return "";
  const date = new Date(iso);
  const offsetMs = date.getTimezoneOffset() * 60 * 1000;
  return new Date(date.getTime() - offsetMs).toISOString().slice(0, 16);
};

const PRESETS = [
  { label: "30 min", minutes: 30 },
  { label: "1 hour", minutes: 60 },
  { label: "2 hours", minutes: 120 },
  { label: "6 hours", minutes: 360 },
  { label: "24 hours", minutes: 1440 },
];

const emptyForm = {
  enabled: false,
  startTime: "",
  endTime: "",
  message: DEFAULT_MESSAGE,
};

const AdminMaintenance = () => {
  const [form, setForm] = useState(emptyForm);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [custom, setCustom] = useState({ hours: "", minutes: "" });
  const [now, setNow] = useState(Date.now());

  // Ticks every second so the live countdown below stays current.
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const load = () => {
    setLoading(true);
    api
      .get("/settings/maintenance", { auth: false })
      .then((res) => {
        const m = res?.maintenance || {};
        setStatus(m);
        setForm({
          enabled: Boolean(m.enabled),
          startTime: toLocalInputValue(m.startTime),
          endTime: toLocalInputValue(m.endTime),
          message: m.message || DEFAULT_MESSAGE,
        });
      })
      .catch(() => toast.error("Couldn't load maintenance settings."))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const handleChange = (field) => (e) => {
    const value =
      e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const save = async (overrides = {}) => {
    const next = { ...form, ...overrides };

    if (
      next.startTime &&
      next.endTime &&
      new Date(next.endTime) <= new Date(next.startTime)
    ) {
      toast.error("End time must be after the start time.");
      return;
    }

    setSaving(true);
    try {
      const res = await api.put("/settings/maintenance", {
        enabled: next.enabled,
        startTime: next.startTime ? new Date(next.startTime).toISOString() : null,
        endTime: next.endTime ? new Date(next.endTime).toISOString() : null,
        message: next.message,
      });

      setStatus(res.maintenance);
      setForm((prev) => ({ ...prev, enabled: Boolean(res.maintenance?.enabled) }));
      toast.success(
        res.maintenance?.enabled
          ? "Maintenance mode is on."
          : "Maintenance mode is off."
      );
    } catch (error) {
      toast.error(error.message || "Couldn't save maintenance settings.");
    } finally {
      setSaving(false);
    }
  };

  const startCustom = () => {
    const total =
      (Number(custom.hours) || 0) * 60 + (Number(custom.minutes) || 0);

    if (total < 1) {
      toast.error("Enter a timer of at least 1 minute.");
      return;
    }

    startFor(total);
  };

  const remainingMs =
    status?.active && status?.endTime
      ? Math.max(0, new Date(status.endTime).getTime() - now)
      : null;

  const formatRemaining = (ms) => {
    const total = Math.floor(ms / 1000);
    const d = Math.floor(total / 86400);
    const h = Math.floor((total % 86400) / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return `${d ? `${d}d ` : ""}${pad(h)}:${pad(m)}:${pad(s)}`;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    save();
  };

  const toggleNow = () => save({ enabled: !form.enabled });

  // One click: start maintenance right now and end it automatically after
  // the chosen duration (the storefront countdown follows the end time).
  const startFor = (minutes) =>
    save({
      enabled: true,
      startTime: "",
      endTime: toLocalInputValue(
        new Date(Date.now() + minutes * 60 * 1000).toISOString()
      ),
    });

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black flex items-center gap-3">
            <FiTool /> Maintenance Mode
          </h1>
          <p className="text-gray-500 mt-1">
            Take the storefront offline for customers during a chosen window.
            Admins and managers can still sign in and use the dashboard.
          </p>
        </div>

        {!loading && (
          <span
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold ${
              status?.active
                ? "bg-red-100 text-red-700"
                : "bg-green-100 text-green-700"
            }`}
          >
            <span
              className={`h-2 w-2 rounded-full ${
                status?.active ? "bg-red-500" : "bg-green-500"
              }`}
            />
            {status?.active
              ? "Maintenance is live"
              : status?.enabled && status?.startTime
              ? "Maintenance scheduled"
              : "Site is live"}
          </span>
        )}
      </div>

      {loading ? (
        <div className="bg-white rounded-2xl shadow p-10 text-center text-gray-400">
          Loading maintenance settings…
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl shadow p-6 grid grid-cols-1 md:grid-cols-2 gap-5"
        >
          <div className="md:col-span-2 flex items-center justify-between rounded-xl border border-gray-200 p-4">
            <div>
              <p className="font-semibold">Maintenance mode</p>
              <p className="text-sm text-gray-500">
                Master switch — turning this off ends maintenance immediately,
                regardless of the time window below.
              </p>
            </div>

            <button
              type="button"
              onClick={toggleNow}
              disabled={saving}
              className={`inline-flex items-center gap-2 px-5 py-3 rounded-xl font-semibold transition disabled:opacity-60 ${
                form.enabled
                  ? "bg-red-600 text-white hover:bg-red-700"
                  : "bg-brand-primary text-white hover:bg-brand-brown"
              }`}
            >
              <FiPower />
              {form.enabled ? "Turn Off" : "Turn On"}
            </button>
          </div>

          <div className="md:col-span-2 rounded-xl border border-gray-200 p-4">
            <p className="font-semibold">Quick timer</p>
            <p className="text-sm text-gray-500 mb-3">
              Start maintenance now and let it end by itself after:
            </p>
            {remainingMs !== null && (
              <p className="mb-3 text-sm font-semibold text-red-700">
                Time left: {formatRemaining(remainingMs)}
              </p>
            )}
            <div className="flex flex-wrap gap-2">
              {PRESETS.map((preset) => (
                <button
                  key={preset.minutes}
                  type="button"
                  disabled={saving}
                  onClick={() => startFor(preset.minutes)}
                  className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-semibold hover:bg-gray-50 transition disabled:opacity-60"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="mt-4 flex flex-wrap items-end gap-3">
              <div>
                <label className="block text-xs text-gray-500 mb-1">Hours</label>
                <input
                  type="number"
                  min="0"
                  value={custom.hours}
                  onChange={(e) =>
                    setCustom((prev) => ({ ...prev, hours: e.target.value }))
                  }
                  placeholder="0"
                  className="w-24 border border-gray-200 rounded-xl p-2.5 focus:outline-none focus:border-brand-primary"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-500 mb-1">Minutes</label>
                <input
                  type="number"
                  min="0"
                  value={custom.minutes}
                  onChange={(e) =>
                    setCustom((prev) => ({ ...prev, minutes: e.target.value }))
                  }
                  placeholder="0"
                  className="w-24 border border-gray-200 rounded-xl p-2.5 focus:outline-none focus:border-brand-primary"
                />
              </div>
              <button
                type="button"
                disabled={saving}
                onClick={startCustom}
                className="px-5 py-2.5 rounded-xl bg-brand-primary text-white text-sm font-semibold hover:bg-brand-brown transition disabled:opacity-60"
              >
                Start custom timer
              </button>
            </div>
          </div>

          <div>
            <label className="font-semibold block mb-2">
              Starts at (optional)
            </label>
            <input
              type="datetime-local"
              value={form.startTime}
              onChange={handleChange("startTime")}
              className="w-full border border-gray-200 rounded-xl p-3 focus:outline-none focus:border-brand-primary"
            />
            <p className="text-xs text-gray-400 mt-1">
              Leave blank to start as soon as the switch above is on.
            </p>
          </div>

          <div>
            <label className="font-semibold block mb-2">
              Ends at (optional)
            </label>
            <input
              type="datetime-local"
              value={form.endTime}
              onChange={handleChange("endTime")}
              className="w-full border border-gray-200 rounded-xl p-3 focus:outline-none focus:border-brand-primary"
            />
            <p className="text-xs text-gray-400 mt-1">
              Leave blank to stay on until you turn it off manually.
            </p>
          </div>

          <div className="md:col-span-2">
            <label className="font-semibold block mb-2">
              Message shown to customers
            </label>
            <textarea
              value={form.message}
              onChange={handleChange("message")}
              rows={3}
              maxLength={300}
              placeholder={DEFAULT_MESSAGE}
              className="w-full border border-gray-200 rounded-xl p-3 focus:outline-none focus:border-brand-primary"
            />
          </div>

          <div className="md:col-span-2 flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={load}
              disabled={saving}
              className="px-6 py-3 rounded-xl border border-gray-200 font-semibold hover:bg-gray-50 transition disabled:opacity-60"
            >
              Reset
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-brand-primary text-white font-semibold hover:bg-brand-brown transition disabled:opacity-60"
            >
              <FiSave />
              {saving ? "Saving..." : "Save Settings"}
            </button>
          </div>
        </form>
      )}
    </AdminLayout>
  );
};

export default AdminMaintenance;