import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  FiUser,
  FiMail,
  FiPhone,
  FiArrowLeft,
  FiShield,
  FiTruck,
  FiRefreshCw,
} from "react-icons/fi";
import toast from "react-hot-toast";

import PasswordInput from "./PasswordInput";
import { useAuth } from "../../hooks/useAuth";

const RegisterForm = () => {
  const navigate = useNavigate();
  const { register } = useAuth();

  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    mobile: "",
    password: "",
    confirmPassword: "",
  });

  const [acceptTerms, setAcceptTerms] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));

    setErrors((prev) => ({
      ...prev,
      [e.target.name]: "",
    }));
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = "First name is required";
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = "Last name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(
        formData.email
      )
    ) {
      newErrors.email = "Invalid email address";
    }

    if (!formData.mobile.trim()) {
      newErrors.mobile = "Mobile number is required";
    } else if (!/^[6-9]\d{9}$/.test(formData.mobile)) {
      newErrors.mobile = "Enter a valid 10-digit mobile number";
    }

    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = "Confirm your password";
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }

    if (!acceptTerms) {
      newErrors.terms = "Please accept the Terms & Conditions";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    setLoading(true);

    try {
      await register(formData);

      toast.success("Account created successfully!");
      navigate("/login");
    } catch (error) {
      toast.error(error?.message || "Registration failed.");
    } finally {
      setLoading(false);
    }
  };

  const inputClass = (field) => `
    w-full h-[58px]
    pl-12 pr-4
    bg-transparent
    border-0 border-b
    ${errors[field] ? "border-red-400" : "border-gray-300"}
    rounded-none
    text-[#082544]
    placeholder:text-[#858995]
    outline-none
    focus:border-[#082544]
    focus:ring-0
    transition-all duration-300
  `;

  const IconWrapper = ({ children }) => (
    <span className="absolute left-0 top-1/2 -translate-y-1/2 text-[#123d68] text-xl">
      {children}
    </span>
  );

  return (
    <div className="min-h-screen w-full bg-white">
      <div className="grid min-h-screen grid-cols-1 lg:grid-cols-2">

        {/* LEFT PANEL */}

        <section className="relative flex min-h-[420px] flex-col justify-between overflow-hidden bg-[#061f3d] px-8 py-10 text-white sm:px-12 lg:min-h-screen lg:px-[8.3%] lg:py-16">

          {/* Subtle dotted background */}

          <div
            className="pointer-events-none absolute inset-0 opacity-[0.12]"
            style={{
              backgroundImage:
                "radial-gradient(#b8c9df 0.8px, transparent 0.8px)",
              backgroundSize: "32px 32px",
            }}
          />

          <div className="relative z-10">

            {/* Brand */}

            <Link
              to="/"
              className="inline-block font-serif text-4xl italic tracking-tight text-white sm:text-5xl"
            >
              Orbit Bay
            </Link>

            {/* Welcome content */}

            <div className="mt-14 max-w-lg sm:mt-16 lg:mt-16">

              <p className="mb-7 text-xs font-bold uppercase tracking-[0.38em] text-[#ddc5a3]">
                Member Access
              </p>

              <h1 className="font-serif text-5xl leading-[1.08] tracking-tight sm:text-6xl lg:text-[68px]">
                Join Our
                <br />
                Community.
              </h1>

              <p className="mt-8 max-w-md text-base leading-8 text-slate-300 sm:text-lg">
                Create your account to save your wishlist, track your
                orders, and discover exclusive member-only offers
                across our collection.
              </p>

            </div>
          </div>

          {/* Benefits */}

          <div className="relative z-10 mt-12 max-w-2xl">

            <div className="mb-7 border-t border-white/15" />

            <div className="space-y-5">

              <div className="flex items-center gap-5">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/10 text-[#ddc5a3]">
                  <FiShield size={20} />
                </span>

                <p className="text-base font-medium text-slate-200 sm:text-lg">
                  Secure and protected account
                </p>
              </div>

              <div className="flex items-center gap-5">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/10 text-[#ddc5a3]">
                  <FiTruck size={20} />
                </span>

                <p className="text-base font-medium text-slate-200 sm:text-lg">
                  Fast, tracked delivery
                </p>
              </div>

              <div className="flex items-center gap-5">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/10 text-[#ddc5a3]">
                  <FiRefreshCw size={20} />
                </span>

                <p className="text-base font-medium text-slate-200 sm:text-lg">
                  Hassle-free shopping experience
                </p>
              </div>

            </div>
          </div>

        </section>

        {/* RIGHT PANEL */}

        <section className="flex min-h-screen flex-col bg-white px-6 py-8 sm:px-12 lg:px-16 xl:px-20">

          {/* Back to home */}

          <div className="mx-auto w-full max-w-[530px]">

            <Link
              to="/"
              className="inline-flex items-center gap-3 text-sm font-semibold text-[#68778c] transition-colors hover:text-[#061f3d]"
            >
              <FiArrowLeft size={17} />
              Back to Home
            </Link>

          </div>

          {/* Registration form */}

          <div className="mx-auto my-auto w-full max-w-[530px] py-12">

            <div className="mb-9">

              <h2 className="font-serif text-4xl tracking-tight text-[#061f3d] sm:text-[42px]">
                Create Account
              </h2>

              <p className="mt-3 text-base leading-7 text-[#68778c] sm:text-lg">
                Enter your details to create your account.
              </p>

            </div>

            <form onSubmit={handleSubmit} className="space-y-5">

              {/* First and last name */}

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">

                <div>
                  <label
                    htmlFor="firstName"
                    className="sr-only"
                  >
                    First Name
                  </label>

                  <div className="relative">
                    <IconWrapper>
                      <FiUser />
                    </IconWrapper>

                    <input
                      id="firstName"
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleChange}
                      placeholder="First Name"
                      autoComplete="given-name"
                      aria-invalid={!!errors.firstName}
                      className={inputClass("firstName")}
                    />
                  </div>

                  {errors.firstName && (
                    <p className="mt-2 text-sm text-red-500">
                      {errors.firstName}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="lastName"
                    className="sr-only"
                  >
                    Last Name
                  </label>

                  <div className="relative">
                    <IconWrapper>
                      <FiUser />
                    </IconWrapper>

                    <input
                      id="lastName"
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleChange}
                      placeholder="Last Name"
                      autoComplete="family-name"
                      aria-invalid={!!errors.lastName}
                      className={inputClass("lastName")}
                    />
                  </div>

                  {errors.lastName && (
                    <p className="mt-2 text-sm text-red-500">
                      {errors.lastName}
                    </p>
                  )}
                </div>

              </div>

              {/* Email */}

              <div>
                <label htmlFor="email" className="sr-only">
                  Email Address
                </label>

                <div className="relative">
                  <IconWrapper>
                    <FiMail />
                  </IconWrapper>

                  <input
                    id="email"
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Email Address"
                    autoComplete="email"
                    aria-invalid={!!errors.email}
                    className={inputClass("email")}
                  />
                </div>

                {errors.email && (
                  <p className="mt-2 text-sm text-red-500">
                    {errors.email}
                  </p>
                )}
              </div>

              {/* Mobile number */}

              <div>
                <label htmlFor="mobile" className="sr-only">
                  Mobile Number
                </label>

                <div className="relative">
                  <IconWrapper>
                    <FiPhone />
                  </IconWrapper>

                  <input
                    id="mobile"
                    type="tel"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    placeholder="Mobile Number"
                    autoComplete="tel"
                    inputMode="numeric"
                    maxLength={10}
                    aria-invalid={!!errors.mobile}
                    className={inputClass("mobile")}
                  />
                </div>

                {errors.mobile && (
                  <p className="mt-2 text-sm text-red-500">
                    {errors.mobile}
                  </p>
                )}
              </div>

              {/* Password */}

              <div>
                <label className="sr-only" htmlFor="password">
                  Password
                </label>

                <PasswordInput
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Password"
                  error={errors.password}
                  autoComplete="new-password"
                />
              </div>

              {/* Confirm password */}

              <div>
                <label
                  className="sr-only"
                  htmlFor="confirmPassword"
                >
                  Confirm Password
                </label>

                <PasswordInput
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="Confirm Password"
                  error={errors.confirmPassword}
                  autoComplete="new-password"
                />
              </div>

              {/* Terms and conditions */}

              <div className="pt-1">

                <label className="flex cursor-pointer items-start gap-3">

                  <input
                    type="checkbox"
                    checked={acceptTerms}
                    onChange={(e) =>
                      setAcceptTerms(e.target.checked)
                    }
                    className="mt-1 h-4 w-4 shrink-0 accent-[#061f3d]"
                  />

                  <span className="text-sm leading-6 text-[#68778c]">
                    I agree to the{" "}
                    <Link
                      to="/terms"
                      className="font-semibold text-[#061f3d] hover:underline"
                    >
                      Terms & Conditions
                    </Link>{" "}
                    and{" "}
                    <Link
                      to="/privacy"
                      className="font-semibold text-[#061f3d] hover:underline"
                    >
                      Privacy Policy
                    </Link>
                    .
                  </span>

                </label>

                {errors.terms && (
                  <p className="mt-2 text-sm text-red-500">
                    {errors.terms}
                  </p>
                )}

              </div>

              {/* Create account button */}

              <button
                type="submit"
                disabled={loading}
                className="
                  mt-3 flex h-[70px] w-full items-center
                  justify-center rounded-full
                  bg-[#061f3d] px-6
                  text-lg font-semibold text-white
                  transition-all duration-300
                  hover:bg-[#123d68]
                  hover:shadow-lg
                  disabled:cursor-not-allowed
                  disabled:opacity-60
                "
              >
                {loading ? "Creating Account..." : "Create Account"}
              </button>

              {/* Sign in link */}

              <div className="pt-4 text-center">

                <p className="text-sm text-[#68778c] sm:text-base">
                  Already have an account?{" "}

                  <Link
                    to="/login"
                    className="font-bold text-[#061f3d] transition-colors hover:text-[#123d68]"
                  >
                    Sign In
                  </Link>
                </p>

              </div>

            </form>

          </div>

        </section>

      </div>
    </div>
  );
};

export default RegisterForm;